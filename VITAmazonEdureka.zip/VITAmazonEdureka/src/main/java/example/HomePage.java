package example;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HomePage {

    WebDriver driver;

    @FindBy(xpath = "//span[normalize-space()='Account & Lists']")
    WebElement accountsAndLists;

    @FindBy(xpath = "//span[normalize-space()='Create a Wish List']")
    WebElement createWishList;

    @FindBy(xpath = "//a[normalize-space()='Amazon Pay']")
    WebElement amazonPay;

    @FindBy(xpath = "//a[normalize-space()='New Releases']")
    WebElement newReleases;

    public HomePage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void navigateToCreateWishList() {
        Actions actions = new Actions(driver);
        actions.moveToElement(accountsAndLists).perform();  // Hover over 'Account & Lists'
        createWishList.click();  // Click on 'Create a Wish List'
    }

    public void navigateToAmazonPay() {
        amazonPay.click();  // Click on 'Amazon Pay'
    }

    public void navigateToNewReleases() {
        newReleases.click();  // Click on 'New Releases'
    }
}
