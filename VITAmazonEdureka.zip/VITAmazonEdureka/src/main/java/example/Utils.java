package example;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Utils {
    private static WebDriver driver;
    private static Properties properties;

    public static void loadProperties() {
        properties = new Properties();
        try {
            FileInputStream inputStream = new FileInputStream("src\\main\\java\\resources\\config.properties");
            properties.load(inputStream);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void setupBrowser() {
        loadProperties();
        String browser = properties.getProperty("browser");
        if (browser.equalsIgnoreCase("chrome")) {
            System.setProperty("webdriver.chrome.driver", "..\\VITAmazonEdureka\\Drivers\\chromedriver.exe");
            driver = new ChromeDriver();

			
			//Maximize window
			driver.manage().window().maximize();
			
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
        }
        driver.get(properties.getProperty("url"));
    }

    public static WebDriver getDriver() {
        return driver;
    }

    public static void quitBrowser() {
        if (driver != null) {
            driver.quit();
        }
    }
}