package example;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;

public class Navigation {
    static WebDriver driver;
    HomePage homePage;
    LoginPage loginPage;
    SearchPage searchPage;

    public Navigation(WebDriver driver) {
        this.driver = driver;
        homePage = new HomePage(driver);
        loginPage = new LoginPage(driver);
        searchPage = new SearchPage(driver);
    }
    
    public void navigateToCreateWishList() {
        homePage.navigateToCreateWishList();
    }

    public void login(String username, String password) {
        loginPage.login(username, password);
    }

    public void search(String query) {
        searchPage.search(query);
    }
    public String getUrl() {
    	return driver.getCurrentUrl();
    }
    public void navigateToAmazonPay() {
        homePage.navigateToAmazonPay();
    }
    public void navigateToNewReleases() {
        homePage.navigateToNewReleases();
    }
    public void validateURL(String expectedURL) {
        String actualURL = driver.getCurrentUrl();
        Assert.assertTrue(actualURL.contains(expectedURL));
    }
    
    public void goToHomePage() {
        driver.get("https://www.amazon.in");
    }

}