package test;

import org.testng.annotations.Test;

import example.Utils;

import org.testng.annotations.BeforeSuite;
import org.testng.annotations.AfterSuite;

public class BaseTest {
  @Test
  public void f() {
  }
  @BeforeSuite
  public void setUp() {
	  Utils.setupBrowser();
  }

  @AfterSuite
  public void tearDown() {
	  Utils.quitBrowser();
	  System.out.println("Succesfully passed");
  }

}
