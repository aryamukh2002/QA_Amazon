package test;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import example.Navigation;
import example.Utils;

public class LoginTest extends BaseTest{
  
  @Test
  @Parameters({"validUsername", "validPassword"})
  public void validLogin(String username, String password) {
      Navigation navigation = new Navigation(Utils.getDriver());
      navigation.login(username, password);
      // Add validation logic for successful login
  }

  @Test
  @Parameters({"invalidUsername", "invalidPassword"})
  public void invalidLogin(String username, String password) {
      Navigation navigation = new Navigation(Utils.getDriver());
      navigation.login(username, password);
      // Add validation logic for failed login
  }
}
