package test;

import org.testng.Assert;
import org.testng.annotations.Test;

import example.Navigation;
import example.Utils;

public class NavigationTest extends BaseTest {

    @Test
    public void testNavigationToCreateWishList() {
        Navigation navigation = new Navigation(Utils.getDriver());
        navigation.navigateToCreateWishList();
        // Add validation logic to confirm navigation was successful
        String currentURL = navigation.getUrl();
        Assert.assertTrue(currentURL.contains("wishlist"), "Navigation to 'Create a Wish List' failed. Current URL: " + currentURL);
    }

    @Test
    public void testNavigationToAmazonPay() {
        Navigation navigation = new Navigation(Utils.getDriver());
        navigation.navigateToAmazonPay();
        navigation.validateURL("https://www.amazon.in/gp/sva/dashboard?ref_=nav_cs_apay");
        navigation.goToHomePage();
    }
    
    @Test
    public void testNavigationToNewReleases() {
        Navigation navigation = new Navigation(Utils.getDriver());
        navigation.navigateToNewReleases();
        navigation.validateURL("new-releases");
    }
}
