package test;

import java.time.Duration;
import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

import example.Navigation;
import example.ProductPage;
import example.Utils;

public class MobileOrderTest {
	 static WebDriver driver;
  @Test
  public void mobileOrder() {
	  driver =new ChromeDriver();
	  driver.manage().window().maximize();
	  driver.get("https://www.amazon.in/ref=nav_logo");
	  
	  WebElement searchBox= driver.findElement(By.xpath("//input[@id='twotabsearchtextbox']"));
	  searchBox.click();
	  String currentHead =driver.getTitle();
	  searchBox.sendKeys("mi mobile");
	  driver.findElement(By.xpath("//input[@id='nav-search-submit-button']")).click();
	  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
	  Assert.assertNotEquals(currentHead, driver.getTitle(), "Validated");
	  
  }
  @Test(dependsOnMethods = {"mobileOrder"})
  public void findMobile() {
	  driver.findElement(By.xpath("//div[@id='reviewsRefinements']//i[@class='a-icon a-icon-star-medium a-star-medium-4']")).click();
	  String presentUrl=driver.getCurrentUrl();
	  driver.findElement(By.cssSelector("div[class='s-widget-container s-spacing-small s-widget-container-height-small celwidget slot=MAIN template=SEARCH_RESULTS widgetId=search-results_1'] span[class='a-size-medium a-color-base a-text-normal']")).click();
	  Set<String> set=driver.getWindowHandles();
	  Iterator<String> iterator =set.iterator();
		
		String parentWindow=iterator.next();
		String mobileWindow=iterator.next();
		driver.switchTo().window(mobileWindow);
	  
	  
	  
	  Assert.assertNotEquals(presentUrl,driver.getCurrentUrl(),"Validated");
	  
  }
  @Test(dependsOnMethods = {"findMobile"})
  public void checkOrder() {
	  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
	  driver.findElement(By.xpath("//div[@id='contextualIngressPtLabel_deliveryShortLine']")).click();
		//get alert box
		WebElement boxAddress= driver.findElement(By.xpath("//h4[@id='a-popover-header-7']"));
		
		//get alert message
		String message=boxAddress.getText();
		Assert.assertTrue(message.contains("location"));
		String num="700020";
		WebElement pinCode =driver.findElement(By.xpath("//input[@id='GLUXZipUpdateInput']"));
		pinCode.click();
		pinCode.sendKeys(num);
		driver.findElement(By.xpath("//input[@aria-labelledby='GLUXZipUpdate-announce']")).click();
		driver.navigate().refresh();
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(40));
		WebElement addLine = driver.findElement(By.xpath("//div[@id='contextualIngressPtLabel_deliveryShortLine']"));
		String address=addLine.getText();
		System.out.print(address);
		
		Assert.assertTrue(addLine.getText().contains(num));
		driver.findElement(By.xpath("//div[@class='a-section a-spacing-none a-padding-none']//input[@id='add-to-cart-button']")).click();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(40));
		
		WebElement getCart =driver.findElement(By.xpath("//div[@class=\"a-fixed-left-grid\"]//div[@class=\"a-fixed-left-grid-inner a-grid-vertical-align a-grid-top\"]//h4[@class=\"a-alert-heading\"]"));
		String deli=getCart.getText();
		driver.findElement(By.xpath("//a[@aria-label=\"Exit this panel and return to the product page. \"]")).click();
		Assert.assertEquals(deli, "Added to Cart");
		
		 ProductPage productPage = new ProductPage(driver);

	        // Scroll to the "Technical Details" section
	      productPage.scrollToTechnicalDetails();
  }
 
}
