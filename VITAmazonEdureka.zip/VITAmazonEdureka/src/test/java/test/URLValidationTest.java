package test;

import org.testng.Assert;
import org.testng.annotations.Test;

import example.Navigation;
import example.Utils;


public class URLValidationTest extends BaseTest {

    @Test
    public void validateURL() {
        Navigation navigation = new Navigation(Utils.getDriver());
        String expectedUrl = "https://www.amazon.in/";
        String actualUrl = Utils.getDriver().getCurrentUrl();
        navigation.validateURL(expectedUrl);  // Using validateURL method from Navigation class
    }

}
